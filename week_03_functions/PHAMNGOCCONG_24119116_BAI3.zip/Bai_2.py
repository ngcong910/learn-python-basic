def main():
    CK=float(input("Diem chuyen can: "))
    BTL=float(input("Diem bai tap tren lop: "))
    BTN=float(input("Diem bai tap ve nha: "))
    GK=float(input("Diem giua ki: "))
    CK=float(input("Diem cuoi ki: "))
    print_diem_tong(CK,BTN,GK,BTL)
    Tong=print_diem_tong(CK,BTN,GK,BTL)
    print("Diem tong:",Tong)
    print_ket_qua(Tong)
def print_diem_tong(CK,BTN,GK,BTL):
    Tong=CK*0.1+BTL*0.1+BTN*0.1+GK*0.2+CK*0.5
    return Tong
def print_ket_qua(Tong):
    if Tong>=9:
        print("Loại A")
    elif Tong>=7 and Tong<9:
        print("Loai B")
    elif Tong>=5 and Tong <7:
        print("Loai C")
    else:
        print("Loai D")
main()